/*package ordonnancement;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import index.MotFichierOcc;
import lecteur.LecteurFichier;
import lecteur.LecteurMotParMot;


public class Ordonnanceur2 implements Ordonnanceur  {

        public List<Entry<String, Double>> ordonnancer(List<MotFichierOcc> statMot) {
            Map<String, Integer> motsParFichier = new HashMap<>();
            for (MotFichierOcc mot : statMot) {
                motsParFichier.put(mot.getFilePath(), motsParFichier.getOrDefault(mot.getFilePath(), 0) + 1);
            }

            Map<String, Double> fichierScore = new HashMap<>();
            for (Map.Entry<String, Integer> entry : motsParFichier.entrySet()) {
                List<String>filr =entry.getKey()
                double bonus = (double) entry.getValue()/.10 ;
                fichierScore.put(entry.getKey(), bonus);
            }
    
            Map<String, Double> scoreFichier = new HashMap<>();
            for (MotFichierOcc mot : statMot) {
                double occurences = mot.getocc();
                double score = occurences;
                scoreFichier.put(mot.getFilePath(), score);
            }
    
            // Calculer le score final de chaque fichier
            Map<String, Double> fichierScoreFinal = new HashMap<>();
            for (Map.Entry<String, Double> entry : fichierScore.entrySet()) {
                String fichier = entry.getKey();
                double bonus = entry.getValue();
                double score = scoreFichier.getOrDefault(fichier, 0.0);
                double scoreFinal = (score + bonus)*0;
                fichierScoreFinal.put(fichier, scoreFinal);
            }
    
            // Trier les fichiers par leur score final
            List<Entry<String, Double>> fichiersOrdonnes = fichierScoreFinal.entrySet().stream()
                    .sorted(Map.Entry.<String, Double>comparingByValue().reversed())
                    .collect(Collectors.toList());
    
            return fichiersOrdonnes;
        }
    }*/
    package ordonnancement;

    import java.util.ArrayList;
    import java.util.Collections;
    import java.util.Comparator;
    import java.util.HashMap;
    import java.util.List;
    import java.util.Map;
    import java.util.Map.Entry;
    import index.MotFichierOcc;
    
    public class Ordonnanceur2 implements Ordonnanceur {
        @Override
        public List<Entry<String, Double>> ordonnancer(List<MotFichierOcc> statMot) {
            Map<String, Double> fichierBonus = new HashMap<>();
            for (MotFichierOcc mot : statMot) {
                fichierBonus.put(mot.getFilePath(), fichierBonus.getOrDefault(mot.getFilePath(), 0.0) + mot.getocc());
            }

            List<Entry<String, Double>> fichiersScores = new ArrayList<>();
            for (MotFichierOcc mot : statMot) {
                String fichier = mot.getFilePath();
                double scoreFinal = mot.getocc() + fichierBonus.get(fichier);
                fichiersScores.add(Map.entry(fichier, scoreFinal));
            }
            Collections.sort(fichiersScores,Comparator.comparing(Map.Entry<String, Double>::getValue,Comparator.reverseOrder()));
            List<Map.Entry<String, Double>> dixPremiers = fichiersScores.subList(0, Math.min(10, fichiersScores.size()));

            return dixPremiers;
        }
    
        
    }
    