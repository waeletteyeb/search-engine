package ordonnancement;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import index.*;


import java.util.HashMap;


public class Ordonnanceur1 implements Ordonnanceur{
	public List<Map.Entry<String, Double>> ordonnancer(List<MotFichierOcc> statMot){
		Map<String,Double> mapScore=new HashMap<>();

		for (MotFichierOcc i : statMot) {
			mapScore.put(i.getFilePath(), mapScore.getOrDefault(i.getFilePath(), 0.0) + i.getocc());
		}
		List<Map.Entry<String, Double>> listScore=new ArrayList<Map.Entry<String, Double>>(mapScore.entrySet());
		
		Collections.sort(listScore,Comparator.comparing(Map.Entry<String, Double>::getValue));
		
		List<Map.Entry<String, Double>> dixPremiers = listScore.subList(0, Math.min(10, listScore.size()));

		return dixPremiers;
	}








}
