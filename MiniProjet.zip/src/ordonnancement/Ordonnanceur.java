package ordonnancement;

import java.util.List;
import java.util.Map;

import index.MotFichierOcc;

public interface Ordonnanceur {
    public List<Map.Entry<String, Double>> ordonnancer(List<MotFichierOcc> statMot);
}
