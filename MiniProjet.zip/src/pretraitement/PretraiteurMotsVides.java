package pretraitement;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PretraiteurMotsVides implements Pretraiteur {
    public List<String> pretraiter(List<String> fichierLu) {
        List<String> prepositions = new ArrayList<>(Arrays.asList(
            "à", "après", "avant", "avec", "chez", "contre", "dans", "de", "depuis",
            "derrière", "devant", "en", "entre", "hors", "jusque", "par", "pour",
            "sans", "selon", "sous", "sur", "vers", "pendant", "travers"));

        for (int i = 0; i < fichierLu.size(); i++) {
            String mot = fichierLu.get(i);
            if (prepositions.contains(mot)) {
                fichierLu.remove(i);
                i--;
            }
        }
        return fichierLu;
    }
}
