package pretraitement;

import java.util.List;

public interface Pretraiteur {
	List<String> pretraiter(List<String> fichierLu );

}
