package pretraitement;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PretraiteurChiffre implements Pretraiteur {
    private List<String> chiffres = Arrays.asList(
        "0","1","2","3","4","5","6","7","8","9");

    
    public List<String> pretraiter(List<String> motsLus) {
        
            List<String> motsNettoyes = new ArrayList<>();
            
            for (String mot : motsLus) {
                if (!mot.trim().isEmpty()) {
                    StringBuilder motNettoye = new StringBuilder();
                    for (int j = 0; j < mot.length(); j++) {
                        char caractere = mot.charAt(j);
                        if (!chiffres.contains(String.valueOf(caractere))) {
                            motNettoye.append(caractere);
                        }
                    }
                    motsNettoyes.add(motNettoye.toString());
                }
            }
            motsNettoyes.removeIf(String::isEmpty);
            
            return motsNettoyes;
        } 

    

    
}