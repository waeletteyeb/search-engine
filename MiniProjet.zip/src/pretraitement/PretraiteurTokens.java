package pretraitement;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PretraiteurTokens implements Pretraiteur {
    public List<String> pretraiter(List<String> fichierLu) {
        List<String> terminaisons = Arrays.asList(
            "er", "ir", "oir", "re", "oir", "dre", "indre", "ttre", "te", "ttre", "crire", "uire", "oindre", "aître",
            "é", "i", "u", "us", "ue", "ues", "t", "te", "tes", "s", "es", "ies", "ues", "ue", "i", "is", "it", "îmes", "îtes", "urent", "ut",
            "ant", "issant", "is", "us", "ue", "ues", "i", "is", "e", "es", "ent", "ant", "yant", "issant", "ant", "el", "elle",
            "ai", "as", "a", "âmes", "âtes", "èrent", "is", "is", "it", "îmes", "îtes", "irent",
            "ais", "ais", "ait", "ions", "iez", "aient",
            "ai", "as", "a", "ons", "ez", "ont",
            "ais", "ais", "ait", "ions", "iez", "aient",
            "e", "es", "e", "ions", "iez", "ent",
            "asse", "asses", "ât", "assions", "assiez", "assent",
            "e", "ons", "ez", "ez", "e", "e", "ons", "ez",
            "ant", "ayant", "ant", "ant", "ant"
        );

        List<String> pretraites = new ArrayList<>();
        
        for (String mot : fichierLu) {
            for (String terminaison : terminaisons) {
                if (mot.endsWith(terminaison)) {
                    String motPretraite = mot.substring(0, mot.length() - terminaison.length());
                    pretraites.add(motPretraite);
                    break;
                }
            }
        }
        
        return pretraites;
    }
}

        
