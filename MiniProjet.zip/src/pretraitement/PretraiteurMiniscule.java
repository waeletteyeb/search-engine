package pretraitement;

import java.util.ArrayList;
import java.util.List;

public class PretraiteurMiniscule  implements Pretraiteur{

    public List<String> pretraiter (List<String> fichierLu){
       List<String> fichierMiniscule = new ArrayList<>();
        for (String mot : fichierLu) {
            fichierMiniscule.add(mot.toLowerCase());
        }
    
        return fichierMiniscule;
    }

}
