package pretraitement;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;


public class PretraiteurSymboles implements Pretraiteur {

    private List<String> symboles = Arrays.asList(
        " ", ".", ",", ";", ":", "?", "!", "'","~", "`", "@", "#", "$", "%", "^", "&", "*", "(", ")", "_", "-", "+", "=", "[", "]", "{", "}", "|", "\\", 
        "\"", ":", ";", "'", "<", ">", ",", ".", "/", "?");

    
        public List<String> pretraiter(List<String> motsLus) {
        
            List<String> motsNettoyes = new ArrayList<>();
            
            for (String mot : motsLus) {
                if (!mot.trim().isEmpty()) {
                    StringBuilder motNettoye = new StringBuilder();
                    for (int j = 0; j < mot.length(); j++) {
                        char caractere = mot.charAt(j);
                        if (!symboles.contains(String.valueOf(caractere))) {
                            motNettoye.append(caractere);
                        }
                    }
                    motsNettoyes.add(motNettoye.toString());
                }
            }
            motsNettoyes.removeIf(String::isEmpty);
            
            return motsNettoyes;
        } 
    }

            

