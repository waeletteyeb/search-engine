package index;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class IndexMotFichierOcc implements Index{
    
    private List<MotFichierOcc> listeIndex ;

    public IndexMotFichierOcc(){
        this.listeIndex = new ArrayList<MotFichierOcc>();
    }
    

    public void indexer(Map<String,Double> motStat, String path ){
        for (Map.Entry<String, Double> entry : motStat.entrySet()) {
            listeIndex.add(new MotFichierOcc(path, entry.getKey(), entry.getValue()));
    }   
}


public List<MotFichierOcc> getScore(List<String> requete){
    List<MotFichierOcc> statMot = new ArrayList<>();
    for(String r : requete) {
        for(MotFichierOcc i : listeIndex) {
            if(r.equals(i.getMot())) {
                statMot.add(i);
            }
        }
    }
    return statMot;
}


public List<MotFichierOcc> getListeIndex() {
    return listeIndex;
}

}
