package index;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class IndexMap  implements Index {
    private Map<String, Map<String, Double>> mapIndex = new HashMap<>();

    public void indexer(Map<String, Double> mapStat, String filePath) {
        for (String mot : mapStat.keySet()) {
            Map<String, Double> map = mapIndex.get(mot);
            if (map == null) {
                Map<String, Double> map1 = new HashMap<>();
                map1.put(filePath, mapStat.get(mot));
                mapIndex.put(mot, map1);
            } else {
                mapIndex.get(mot).put(filePath, mapStat.get(mot));
            }
        }
    }

    public List<MotFichierOcc> getScore(List<String> requete) {
        Map<String, Map<String, Double>> motStat = new HashMap<>();
        for (String mot : requete) {
            if (mapIndex.containsKey(mot)) {
                motStat.put(mot, mapIndex.get(mot));
            }
        }

        List<MotFichierOcc> resultat = new ArrayList<>();
        for (Map.Entry<String, Map<String, Double>> entry : motStat.entrySet()) {
            String mot = entry.getKey();
            Map<String, Double> mapFichierOcc = entry.getValue();
            for (Map.Entry<String, Double> fichierOcc : mapFichierOcc.entrySet()) {
                String fichier = fichierOcc.getKey();
                Double occurence = fichierOcc.getValue();
                resultat.add(new MotFichierOcc(fichier, mot, occurence));
            }
        }
        return resultat;
    }
}
