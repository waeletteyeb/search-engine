package index;

import java.util.List;
import java.util.Map;

public interface Index {
	public void indexer(Map<String,Double> motStat, String path );
	public List<MotFichierOcc> getScore(List<String> requete);



}
