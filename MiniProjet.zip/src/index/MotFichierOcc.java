package index;

public class MotFichierOcc {
    private String mot ;
    private double occ;
    private String filePath;

    public String getMot() {
        return mot;
    }
    public void setMot(String mot) {
        this.mot = mot;
    }
    public double getocc() {
        return occ;
    }
    public void setocc(int occ) {
        this.occ = occ;
    }
    public String getFilePath() {
        return filePath;
    }
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public MotFichierOcc(String path, String mot, double occ ){
        this.filePath = path;
        this.mot=mot;
        this.occ=occ;

    }

    

    
}
