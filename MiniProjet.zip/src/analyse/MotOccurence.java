package analyse;

import java.util.Comparator;

public class MotOccurence implements Comparator<MotOccurence>{

    private String mot;
    private double Occ;

    
    public MotOccurence(String mot, double occ) {
        this.mot = mot;
        this.Occ = occ;
    }
    
    public MotOccurence() {
    }

    public String getMot() {
        return mot;
    }
    public void setMot(String mot) {
        this.mot = mot;
    }
    public double getOcc() {
        return Occ;
    }
    public void setOcc(double occ) {
        Occ = occ;
    }
    
    @Override
    public int compare(MotOccurence m1, MotOccurence m2) {
        return Double.compare(m2.getOcc(), m1.getOcc());
    }
}


