package analyse;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Analyseur1 implements Analyseur {


    public Map<String,Double> analyser (List<String> motsNettoyes) {
        Map<String, Double> motStat = new HashMap<>();

        for (String mot : motsNettoyes) {
            motStat.put(mot, (motStat.getOrDefault(mot, 0.0) + 1.0));
        }
        return motStat;
    }
    
}