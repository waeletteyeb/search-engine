package analyse;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Analyseur2 implements Analyseur {
    @Override
    public Map<String, Double> analyser(List<String> motsNettoyes) {
        TreeMap<String, Double> motStat = new TreeMap<>(Comparator.reverseOrder());
        for (String mot : motsNettoyes) {
            motStat.put(mot, (motStat.getOrDefault(mot, 0.0) + 1.0));

        }

        return motStat;
    }
}
