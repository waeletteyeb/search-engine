package lecteur;

import java.util.List;
public interface LecteurFichier {
	
	List<String> lireFichier (String path);

}
