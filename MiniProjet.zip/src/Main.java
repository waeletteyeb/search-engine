import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import analyse.Analyseur;
import analyse.Analyseur1;
import analyse.Analyseur2;
import index.Index;
import index.IndexMap;
import index.IndexMotFichierOcc;
import index.MotFichierOcc;
import lecteur.LecteurFichier;
import lecteur.LecteurMotParMot;
import lecteur.LecteurParLigne;
import ordonnancement.Ordonnanceur;
import ordonnancement.Ordonnanceur1;
import ordonnancement.Ordonnanceur2;
import pretraitement.Pretraiteur;
import pretraitement.PretraiteurChiffre;
import pretraitement.PretraiteurMiniscule;
import pretraitement.PretraiteurMotsVides;
import pretraitement.PretraiteurSymboles;
import pretraitement.PretraiteurTokens;


public class Main {
    
    
    public static void main(String[] args) throws FileNotFoundException {
           
        LecteurFichier lecteur=null;
        List<Pretraiteur> pretraiteurList=new ArrayList<>();
        Analyseur analyseur=null;
        Index index=null;
        Ordonnanceur ordonnanceur=null;
        List<Pretraiteur> pretraiteurParDefaut=new ArrayList<>();
        pretraiteurParDefaut.add(new PretraiteurMiniscule());
        pretraiteurParDefaut.add(new PretraiteurSymboles());
        pretraiteurParDefaut.add(new PretraiteurChiffre());




        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("Taper la requete : ");
            String requete1 = scanner.nextLine();
            System.out.println("Insérez le chemin absolue  : ");
            String requete2= scanner.nextLine();
            String[] motsArray = requete1.split("\\s+");
            List<String> requeteList = Arrays.asList(motsArray);



            
      
      
   
            System.out.println("Choix du  lecteur ");
            System.out.println("Tapez 0 pour le lecteur par défaut ");
            System.out.println("Tapez 1 pour le lecteur mot par mot ");
            System.out.println("Tapez 2 pour le lecteur ligne par ligne");

            int choixLecteur = scanner.nextInt();
            scanner.nextLine();
            switch (choixLecteur) {
                case 1:
                    lecteur=new LecteurMotParMot();
                case 2:
                    lecteur=new LecteurParLigne();
                default:
                    lecteur = new LecteurMotParMot(); 
                    break;
            }


            System.out.println("Choix des prétraiteurs :");
            System.out.println("Tapez 0 pour les prétraiteurs par défaut");
            System.out.println("Tapez 1 pour le prétraiteur des symboles");
            System.out.println("Tapez 2 pour le prétraiteur des mots vides");
            System.out.println("Tapez 3 pour le prétraiteur des tokens");
            System.out.println("Tapez 4 pour le prétraiteur des chiffres");
            System.out.println("Tapez 5 pour le prétraiteur des minuscules");
            System.out.println("Tapez 6 pour valider le choix");
            
            int choixTraiteur = -1;
            while (choixTraiteur != 6) {
                choixTraiteur = scanner.nextInt();
                scanner.nextLine();
            
                switch (choixTraiteur) {
                    case 1:
                        pretraiteurList.add(new PretraiteurSymboles());
                        break;
                    case 2:
                        pretraiteurList.add(new PretraiteurMotsVides());
                        
                        break;
                    case 3:
                        pretraiteurList.add(new PretraiteurTokens());
                        break;
                    case 4:
                        pretraiteurList.add(new PretraiteurChiffre());
                        break;
                    case 5:
                        pretraiteurList.add(new PretraiteurMiniscule());
                        break;
                    case 0:
                        pretraiteurList.clear();
                        pretraiteurList.addAll(pretraiteurParDefaut);
                        choixTraiteur = 6; 
                        break;
                    case 6:
                        break;
                    default:
                        System.out.println("Choix invalide. Veuillez choisir à nouveau.");
                        break;
                }
            }
            for( Pretraiteur p : pretraiteurList ){
                requeteList=p.pretraiter(requeteList);}
            


            System.out.println("choix d'analyseur ");
            System.out.println("Tapez 0 pour l'analyseur par défaut ");
            System.out.println("Tapez 1 pour l'analyseur sans ordre");
            System.out.println("Tapez 2 pour l'analyseur par ordre ");
            int choixAnalyseur = scanner.nextInt();
            scanner.nextLine();
            switch (choixAnalyseur) {
                case 1:
                    analyseur=new Analyseur1();
                case 2:
                    analyseur=new Analyseur2();
                case 0: 
                    analyseur=new Analyseur1();
                default:
                    analyseur=new Analyseur1();
                    break;
            }

            System.out.println("choix d'indexeur ");
            System.out.println("Tapez 0 pour l'indexeur par défaut ");
            System.out.println("Tapez 1 pour l'indexeur par liste");
            System.out.println("Tapez 2 pour l'indexeur par map ");
            int choixIndexeur = scanner.nextInt();
            scanner.nextLine();
            switch (choixIndexeur) {
                case 1:
                    index=new IndexMotFichierOcc();
                case 2:
                    index=new IndexMap();
                case 0: 
                    index=new IndexMap() ;
                default:
                    index = new IndexMap(); 
                break;
            }
            System.out.println("Tapez l'ordonnanceur ");
            System.out.println("Tapez 0 pour l'ordonnanceur par défaut ");
            System.out.println("Tapez 1 pour l'ordonnanceur de type 1");
            System.out.println("Tapez 2 pour l'ordonnanceur de type 2");
            int choixOrdonnanceur = scanner.nextInt();
            scanner.nextLine();
            switch (choixOrdonnanceur) {
                case 1:
                    ordonnanceur=new Ordonnanceur1();
                case 2: 
                    ordonnanceur=new Ordonnanceur1();
                default:
                    ordonnanceur=new Ordonnanceur2();
                }
                long startTime = System.nanoTime();
                MoteurDeRecherche m = new MoteurDeRecherche(pretraiteurList, analyseur, ordonnanceur, index);
                m.index(requete2);
                m.search(requeteList);
                long endTime = System.nanoTime();
                long duration = (endTime - startTime);
                System.out.println(duration); 

        }

 
    }

    
}

