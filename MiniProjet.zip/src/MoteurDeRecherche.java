
import java.io.File;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import analyse.Analyseur;
import analyse.Analyseur1;
import analyse.Analyseur2;
import index.Index;
import index.IndexMotFichierOcc;
import lecteur.LecteurMotParMot;
import ordonnancement.Ordonnanceur;
import ordonnancement.Ordonnanceur1;
import pretraitement.Pretraiteur;
import pretraitement.PretraiteurMiniscule;
import pretraitement.PretraiteurMotsVides;
import pretraitement.PretraiteurSymboles;


public class MoteurDeRecherche {
    private Index index;
    private Ordonnanceur ordonnanceur;
    private Analyseur analyseur;
    private List<Pretraiteur> pretraiteurs;

    public MoteurDeRecherche() {
        this.pretraiteurs = new ArrayList<>(); 
        this.pretraiteurs.add(new PretraiteurSymboles());
        this.pretraiteurs.add(new PretraiteurMiniscule());
        this.analyseur = new Analyseur2();
        this.index = new IndexMotFichierOcc();
        this.ordonnanceur = new Ordonnanceur1();
    }

   public MoteurDeRecherche(List<Pretraiteur> pretraiteurs,Analyseur analyseur,Ordonnanceur ordonnanceur,Index index ) {
	   this.pretraiteurs=pretraiteurs;
	   this.analyseur=analyseur;
	   this.index=index;   
	   this.ordonnanceur = ordonnanceur; 
	      
   }
   
   public Ordonnanceur getOrdonnanceur() {
	   return this.ordonnanceur;
   }
   public Analyseur getAnalyseur() {
	   return this.analyseur;
   }
   public List<Pretraiteur> getPretraiteurs(){
	   return this.pretraiteurs;
   }
    public Index getIndex() {
	   return this.index;
   }
    
    
   public void setOrdonnanceur(Ordonnanceur o) {
	   this.ordonnanceur=o;
   }
   public void setAnalyseur(Analyseur a) {
	   this.analyseur=a;
   }
   public void setPretraiteurs(List<Pretraiteur> p) {
	   this.pretraiteurs=p;
   }
   public void setIndex(Index i) {
	   this.index=i;
   }

    public void index(String path){
        File filePath = Paths.get(path).toFile();

        if(filePath.exists()){
            if(filePath.isDirectory()){
                System.out.println(path+" is a directory");
                indexDirectory(path);
            }else{
                System.out.println(path+" is a file");
                indexSingleDocument(path);
            }
        }else{
            System.out.println(path+" does not exist");
        }
    }



    private void indexSingleDocument(String path){
    	LecteurMotParMot L = new LecteurMotParMot();
        List<String> file = L.lireFichier(path);
        int i = 0;
        while (i < pretraiteurs.size() && i < file.size()) {
            file = pretraiteurs.get(i).pretraiter(file);
            i++;
        }
        index.indexer(analyseur.analyser(file), path);
    }

    private void indexDirectory(String path){
        File pathFile = Paths.get(path).toFile();
        File[] files = pathFile.listFiles();
        for(File f: files ){
            if(f.isDirectory()){
                indexDirectory(f.getAbsolutePath());
            }else{
                indexSingleDocument(f.getAbsolutePath());
            }
        }
    }


     public void search(List<String> requete) {
    	List<Map.Entry<String, Double>> mapScore = ordonnanceur.ordonnancer(index.getScore(requete));
    	 for(Map.Entry<String,Double> i : mapScore) {
    		 System.out.println(i.getKey()+" : "+i.getValue());
    	 }
     } 

    

}

